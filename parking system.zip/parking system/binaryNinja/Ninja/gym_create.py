import sqlite3
connie = sqlite3.connect('gymv2.db')
c = connie.cursor()
c.execute("""
-- CREATE TABLE TRAINER(
--   SSN char(100),
--   Name char(100) ,
--   Surname char(100) ,
--   DateOfBirth Date,
--   Email CHAR(100),
--   PhoneNo CHAR(100),
--   PRIMARY KEY(SSN));
--CREATE TABLE COURSE(
--   CId char(100),
--   Name char(100) ,
--   Type char(100) ,
--   Level INTEGER
--   CHECK(Level IS NOT NULL AND Level>0),
--   PRIMARY KEY(CId));
--pragma FOREIGN_keys=ON;
--CREATE TABLE SCHEDULE(
--   SSN char(100) ,
--   Day char(100) ,
--   StartTime time ,
--   Duration INTEGER 
--   CHECK (Duration>0),
--   CId char(100),
--   GymRoom char(100),
--  PRIMARY KEY (SSN,Day,StartTime),
--   FOREIGN KEY (SSN) REFERENCES TRAINER(SSN),
--   FOREIGN KEY (CId) REFERENCES COURSE(CId)) 
""")
connie.commit()
connie.close()