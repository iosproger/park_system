import random

color = ['white', 'black', 'red', 'grey','yellow','blue']
car_name = ['onix', 'nexia', 'spark', 'cobalt','damas','tracker','maluba','tahoe','eqinoxe']

for i in range(10):
    vin = f'wbc1000fghbvc45p{i}'
    random_color = random.choice(color)
    random_car_name = random.choice(car_name)
    print(f'vin: {vin} color: {random_color} name: {random_car_name}')

for i in range(10,100):
    vin = f'wbc1000yutbik45{i}'
    random_color = random.choice(color)
    random_car_name = random.choice(car_name)
    print(f'vin: {vin} color: {random_color} name: {random_car_name}')