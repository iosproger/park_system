import sqlite3

# Insert data into the table
connie = sqlite3.connect('park.db')
c = connie.cursor()

for i in range(1, 25):
    place = f"1.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 23):
    place = f"2.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 23):
    place = f"3.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 23):
    place = f"4.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 23):
    place = f"5.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 23):
    place = f"6.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 23):
    place = f"7.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

for i in range(1, 25):
    place = f"8.{i}"
    busy = "free"
    vin = "free"

    c.execute("""
    INSERT INTO park(Place, Busy, Vin)
    VALUES(?, ?, ?)
    """, (place, busy, vin))

connie.commit()
connie.close()