import sqlite3
def db_connection():
    conn = None
    try:
        conn = sqlite3.connect("park.db")
    except sqlite3.Error as e:
        print(e)
    return conn

conn = db_connection()
cursor = conn.cursor()

cursor.execute("SELECT * FROM park")
parks = cursor.fetchall()

grouped_parks = {}
for park in parks:
    first_char = park[1][0]  # Get the first character of the place name
    if first_char not in grouped_parks:
        grouped_parks[first_char] = []
    grouped_parks[first_char].append({'Place': park[1], 'Busy': park[2], 'Vin': park[3]})

listt = []
l = []
for i in range(1,25):
    l.append('y')

listt.append(grouped_parks['1']) # 0
listt.append(l)
listt.append(grouped_parks['2']) # 2
listt.append(grouped_parks['3']) # 3
listt.append(l)
listt.append(grouped_parks['4']) # 5
listt.append(grouped_parks['5']) # 6
listt.append(l)
listt.append(grouped_parks['6']) #8
listt.append(grouped_parks['7']) #9
listt.append(l)
listt.append(grouped_parks['8']) #11

listt[2].insert(0,'y')
listt[2].append('y')
listt[3].insert(0,'y')
listt[3].append('y')
listt[5].insert(0,'y')
listt[5].append('y')
listt[6].insert(0,'y')
listt[6].append('y')
listt[8].insert(0,'y')
listt[8].append('y')
listt[9].insert(0,'y')
listt[9].append('y')
listt[11].insert(0,'y')

for i in listt:
    print(i)