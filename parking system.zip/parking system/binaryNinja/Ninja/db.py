import sqlite3

# Create the park database and table
connie = sqlite3.connect('park.db')
c = connie.cursor()

c.execute("""
CREATE TABLE park(
  ID INTEGER PRIMARY KEY AUTOINCREMENT,
  Place TEXT,
  Busy TEXT,
  Vin TEXT
);
""")

connie.commit()
connie.close()

# Create the user database and table
# connieuser = sqlite3.connect('user.db')
# cuser = connieuser.cursor()
#
# cuser.execute("""
# CREATE TABLE user(
#   ID INTEGER PRIMARY KEY AUTOINCREMENT,
#   Name TEXT,
#   Psw TEXT
# );
# """)
#
# connieuser.commit()
# connieuser.close()
#
# # Create the history database and table
# conniehistory = sqlite3.connect('history.db')
# chistory = conniehistory.cursor()
#
# chistory.execute("""
# CREATE TABLE history(
#   ID INTEGER PRIMARY KEY AUTOINCREMENT,
#   Date TEXT,
#   Name TEXT,
#   Place TEXT,
#   Vin TEXT,
#   Take BOOL
# );
# """)
#
# conniehistory.commit()
# conniehistory.close()
